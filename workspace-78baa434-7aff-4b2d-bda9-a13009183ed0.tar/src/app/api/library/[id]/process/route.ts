/**
 * Process (index) a source — extract PDF text, chunk it, extract semantic tags.
 * POST /api/library/[id]/process
 *
 * This is the heavy route: PDF parsing + per-chunk LLM tag extraction.
 * Capped to 30 chunks for tag extraction (in batches of 5 parallel).
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { extractPdf } from '@/lib/rag/pdf'
import {
  chunkTextByLength,
  cleanExtractedText,
  tokenize,
} from '@/lib/rag/arabic'
import { inferBookMeta, extractTags, extractTagsBatch } from '@/lib/rag/llm'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 300

// Simple chapter heuristic — look back from the chunk for a chapter/section heading
const CHAPTER_RE = /^(الفقرة|الفصل|باب|جزء|المقدمة|القسم|المبحث|المطلب|الفرع)\s+[\u0600-\u06FF\w\s\d\.\-:'"]{1,80}$/u

function inferChapterFromText(text: string): string | null {
  const lines = text.split('\n')
  for (const line of lines) {
    const trimmed = line.trim()
    if (CHAPTER_RE.test(trimmed)) return trimmed
  }
  return null
}

export async function POST(
  _req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  let sourceId: string | undefined
  try {
    const { id } = await ctx.params
    sourceId = id
    const source = await db.source.findUnique({ where: { id } })
    if (!source) {
      return NextResponse.json({ error: 'المصدر غير موجود.' }, { status: 404 })
    }

    // Official catalog entries have no real file — they cannot be processed.
    if (source.isOfficial || !source.filePath || source.filePath === '—') {
      return NextResponse.json(
        { error: 'هذا مصدر رسمي مهيكل مسبقًا ولا يحتاج إلى معالجة.' },
        { status: 400 }
      )
    }

    // Idempotent: if already indexed, return immediately.
    if (source.status === 'indexed') {
      return NextResponse.json({
        status: 'indexed',
        pageCount: source.pageCount,
        chunkCount: source.chunkCount,
        needsOCR: source.ocrRequired,
      })
    }

    // Mark processing
    await db.source.update({
      where: { id },
      data: {
        status: 'processing',
        extractionError: null,
      },
    })

    let book
    try {
      book = await extractPdf(source.filePath)
    } catch (err: any) {
      await db.source.update({
        where: { id },
        data: {
          status: 'failed',
          extractionError:
            'تعذّر قراءة ملف PDF. تأكد من صحة الملف أو حاول رفعه مرة أخرى.',
        },
      })
      return NextResponse.json(
        {
          status: 'failed',
          error: 'تعذّر قراءة ملف PDF.',
          detail: String(err?.message || err),
        },
        { status: 500 }
      )
    }

    const { pages, needsOCR, pageCount } = book

    // If extraction returned almost no text, treat as needing OCR
    const textOnlyPages = pages.filter((p) => p.text && p.text.trim().length > 20)
    if (needsOCR && textOnlyPages.length < Math.max(1, Math.ceil(pageCount * 0.4))) {
      await db.source.update({
        where: { id },
        data: {
          status: 'failed',
          ocrRequired: true,
          pageCount,
          extractionError:
            'تعذّر استخراج النص - قد يكون PDF مصورًا ويتطلب OCR',
        },
      })
      return NextResponse.json({
        status: 'failed',
        needsOCR: true,
        error: 'تعذّر استخراج النص - قد يكون PDF مصورًا ويتطلب OCR',
      })
    }

    // Infer metadata from first 3 pages of text
    const firstPagesText = pages
      .slice(0, 3)
      .map((p) => p.text || '')
      .join('\n\n')
      .trim()

    try {
      const meta = await inferBookMeta(firstPagesText, source.fileName)
      if (meta && typeof meta === 'object') {
        const update: Record<string, any> = {}
        // Only fill when fields are empty/null in the source
        if (!source.title && meta.title) update.title = String(meta.title)
        if (!source.author && meta.author) update.author = String(meta.author)
        if (
          !source.edition &&
          meta.edition &&
          String(meta.edition).toLowerCase() !== 'null'
        )
          update.edition = String(meta.edition)
        if (meta.sourceType) {
          const allowed = new Set([
            'tafsir',
            'hadith',
            'fiqh',
            'aqeedah',
            'quran',
            'language',
            'history',
            'general',
          ])
          if (allowed.has(String(meta.sourceType)))
            update.sourceType = String(meta.sourceType)
        }
        if (meta.publisher && !source.publisher)
          update.publisher = String(meta.publisher)
        if (meta.year && typeof meta.year === 'number' && !source.year)
          update.year = Number(meta.year)
        if (Object.keys(update).length > 0) {
          await db.source.update({ where: { id }, data: update })
        }
      }
    } catch {
      // ignore inference errors — we keep the original metadata
    }

    // Chunking: iterate pages, chunk each page, persist with running chunkIndex.
    // First, wipe any prior chunks for this source (idempotent re-processing)
    await db.chunk.deleteMany({ where: { sourceId: id } })

    let chunkIndex = 0
    const createdChunkIds: string[] = []
    const createdForTags: Array<{ id: string; text: string }> = []

    for (const page of pages) {
      const pageText = cleanExtractedText(page.text || '')
      if (!pageText) continue
      const pieces = chunkTextByLength(pageText, 900, 120)
      // Detect chapter heading heuristically from the page text (first lines)
      const chapter = inferChapterFromText(pageText)
      for (const piece of pieces) {
        const text = piece.text
        if (!text || text.trim().length < 5) continue
        const tokens = tokenize(text)
        const chunk = await db.chunk.create({
          data: {
            sourceId: id,
            pageNumber: page.pageNumber,
            chapter,
            section: null,
            chunkIndex: chunkIndex++,
            startOffset: piece.start,
            endOffset: piece.end,
            originalText: text,
            textLength: text.length,
            wordCount: tokens.length,
            keywords: null,
            semanticTags: null,
          },
        })
        createdChunkIds.push(chunk.id)
        createdForTags.push({ id: chunk.id, text })
      }
    }

    // Tag extraction: sample up to 12 longest chunks (lower than 30 to avoid 429s).
    // Tag extraction is purely additive — chunks without tags still match via
    // keyword TF search on `originalText`. So we can safely cap this low.
    const representativeChunks = createdForTags
      .slice()
      .sort((a, b) => b.text.length - a.text.length)
      .slice(0, 12)

    // Process sequentially with bounded concurrency (2) — the rate-limit
    // wrapper in extractTagsBatch handles retries + backoff on 429s.
    if (representativeChunks.length > 0) {
      const tagsArrays = await extractTagsBatch(
        representativeChunks.map((c) => c.text),
        2
      )
      for (let i = 0; i < representativeChunks.length; i++) {
        const tags = tagsArrays[i]
        const chunkId = representativeChunks[i].id
        if (tags && tags.length > 0) {
          try {
            await db.chunk.update({
              where: { id: chunkId },
              data: {
                keywords: tags.join(','),
                semanticTags: tags.join(','),
              },
            })
          } catch {
            // ignore individual update errors
          }
        }
      }
    }

    // Final source update
    await db.source.update({
      where: { id },
      data: {
        status: 'indexed',
        isTextExtracted: true,
        pageCount,
        chunkCount: createdChunkIds.length,
        ocrRequired: needsOCR,
        extractionError: null,
      },
    })

    return NextResponse.json({
      status: 'indexed',
      pageCount,
      chunkCount: createdChunkIds.length,
      needsOCR,
    })
  } catch (err: any) {
    // Mark failed and return
    try {
      if (sourceId) {
        await db.source.update({
          where: { id: sourceId },
          data: {
            status: 'failed',
            extractionError: String(err?.message || err),
          },
        })
      }
    } catch {
      /* ignore */
    }
    return NextResponse.json(
      { error: 'تعذّت معالجة المصدر.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
