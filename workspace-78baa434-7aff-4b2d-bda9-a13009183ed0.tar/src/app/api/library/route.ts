/**
 * Library API
 * GET  /api/library      -> { user: Source[], official: Source[] }
 * POST /api/library      -> multipart/form-data upload, returns { sourceId }
 *
 * Source-grounded RAG platform (Naql Muhaqqiq). Server-side only.
 */
import { NextResponse } from 'next/server'
import fs from 'fs/promises'
import path from 'path'
import { db } from '@/lib/db'
import { seedOfficialCatalog } from '@/lib/rag/registry'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const UPLOAD_DIR = '/home/z/my-project/upload'

// Allowed source types (loose validation; LLM inferBookMeta may correct later)
const ALLOWED_TYPES = new Set([
  'tafsir',
  'hadith',
  'fiqh',
  'aqeedah',
  'quran',
  'language',
  'history',
  'general',
])

export async function GET() {
  try {
    // Seed official catalog if no official sources exist yet
    try {
      const officialCount = await db.source.count({ where: { isOfficial: true } })
      if (officialCount === 0) {
        await seedOfficialCatalog()
      }
    } catch {
      // ignore seeding errors so the route still returns
    }

    const sources = await db.source.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        author: true,
        sourceType: true,
        edition: true,
        publisher: true,
        year: true,
        fileName: true,
        filePath: true,
        fileSize: true,
        pageCount: true,
        chunkCount: true,
        status: true,
        isTextExtracted: true,
        ocrRequired: true,
        extractionError: true,
        trustLevel: true,
        isOfficial: true,
        organization: true,
        allowedUsage: true,
        language: true,
        createdAt: true,
        updatedAt: true,
      },
    })

    const user = sources.filter((s) => !s.isOfficial)
    const official = sources.filter((s) => s.isOfficial)

    return NextResponse.json({ user, official })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر جلب المكتبة.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File | null

    if (!file || typeof file === 'string' || !(file instanceof File)) {
      return NextResponse.json({ error: 'لم يتم إرسال ملف PDF.' }, { status: 400 })
    }

    const fileName = file.name || 'upload.pdf'
    const lower = fileName.toLowerCase()
    if (!lower.endsWith('.pdf')) {
      return NextResponse.json(
        { error: 'النوع غير مدعوم. يُقبل ملف PDF فقط.' },
        { status: 400 }
      )
    }

    const title = (formData.get('title') as string | null)?.trim() || ''
    const author = (formData.get('author') as string | null)?.trim() || ''
    let sourceType = (formData.get('sourceType') as string | null)?.trim() || ''
    if (sourceType && !ALLOWED_TYPES.has(sourceType)) sourceType = ''
    if (!sourceType) sourceType = 'general'
    const edition = (formData.get('edition') as string | null)?.trim() || ''

    // Ensure upload dir exists
    try {
      await fs.mkdir(UPLOAD_DIR, { recursive: true })
    } catch {
      /* ignore */
    }

    // Persist file with cuid-like name
    const id = await makeId()
    const ext = 'pdf'
    const savedName = `${id}.${ext}`
    const uploadPath = path.join(UPLOAD_DIR, savedName)
    const buf = Buffer.from(await file.arrayBuffer())
    await fs.writeFile(uploadPath, buf)

    // Create source row in pending status (no heavy processing inline)
    const source = await db.source.create({
      data: {
        id,
        title: title || stripExt(fileName),
        author: author || null,
        sourceType,
        edition: edition || null,
        language: 'ar',
        fileName,
        filePath: uploadPath,
        fileSize: buf.length,
        trustLevel: 'user_upload',
        isOfficial: false,
        allowedUsage: 'research',
        status: 'pending',
        isTextExtracted: false,
        ocrRequired: false,
        pageCount: 0,
        chunkCount: 0,
      },
    })

    return NextResponse.json({ sourceId: source.id })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر رفع الملف.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}

function stripExt(name: string): string {
  const i = name.lastIndexOf('.')
  return i > 0 ? name.slice(0, i) : name
}

// Generate a cuid-like id (we mirror Prisma's default behavior to set the file name)
async function makeId(): Promise<string> {
  // Use crypto.randomUUID with a prefix to mimic cuid format (25 chars-ish).
  const uuid = crypto.randomUUID().replace(/-/g, '')
  return 'c' + uuid.slice(0, 23)
}
