/**
 * Test-only seed endpoint for QA automation.
 * GET  /api/seed  -> returns test user credentials + indexed sources
 * POST /api/seed  -> accepts a PDF upload + auto-processes it (test-only)
 *
 * In production this route returns 404.
 */
import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const TEST_EMAIL = 'test@naql-muhaqqiq.local'
const TEST_PASSWORD = 'test123456'
const TEST_NAME = 'مستخدم اختبار'

export async function GET() {
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'not available' }, { status: 404 })
  }
  try {
    // Ensure test user exists
    let user = await db.user.findUnique({ where: { email: TEST_EMAIL } })
    if (!user) {
      const passwordHash = await bcrypt.hash(TEST_PASSWORD, 10)
      user = await db.user.create({
        data: { email: TEST_EMAIL, name: TEST_NAME, passwordHash, role: 'user' },
      })
    }

    // Return all indexed sources
    const sources = await db.source.findMany({
      where: { status: 'indexed', isOfficial: false },
      select: {
        id: true,
        title: true,
        author: true,
        sourceType: true,
        status: true,
        chunkCount: true,
        pageCount: true,
      },
    })

    return NextResponse.json({
      environment: process.env.NODE_ENV || 'development',
      user: {
        email: TEST_EMAIL,
        password: TEST_PASSWORD,
        name: TEST_NAME,
        userId: user.id,
      },
      sources,
      hint: 'POST a PDF file to this endpoint to auto-upload + index a test source.',
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'seed failed', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}

export async function POST(req: Request) {
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'not available' }, { status: 404 })
  }
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File | null
    if (!file) {
      return NextResponse.json(
        { error: 'No file provided. Send multipart/form-data with a "file" field.' },
        { status: 400 }
      )
    }
    // Reuse the upload logic by forwarding to /api/library
    const uploadForm = new FormData()
    uploadForm.append('file', file, file.name)
    for (const [k, v] of formData.entries()) {
      if (k !== 'file') uploadForm.append(k, v as string)
    }
    const uploadRes = await fetch(new URL('/api/library', req.url), {
      method: 'POST',
      body: uploadForm,
    })
    const uploadData = await uploadRes.json()
    if (!uploadRes.ok) {
      return NextResponse.json(uploadData, { status: uploadRes.status })
    }
    const sourceId = uploadData.sourceId
    // Auto-process the source
    const processRes = await fetch(new URL(`/api/library/${sourceId}/process`, req.url), {
      method: 'POST',
    })
    const processData = await processRes.json()
    return NextResponse.json({
      sourceId,
      process: processData,
      testUser: { email: TEST_EMAIL, password: TEST_PASSWORD },
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'seed upload failed', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
